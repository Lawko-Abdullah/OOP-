﻿using System;

namespace EnkelInkapsling
{
    class Program
    {
        static void Main(string[] args)
        {
            // Skapa ett nytt objekt ! objekt objekt objeeekt
            Person person = new Person();

            // Sätt namnet med hjälp av set-metoden
            person.SetName("Lawko");

            // skriv ut namnet med hjälp av get-metoden funkade efter 100 försök
            Console.WriteLine("Personens namn är: " + person.GetName());
        }
    }

    //  Person-klass med inkapsling 
    class Person
    {
        // Privat string för namn (kan bara nås inom klassen) alltså inte offentligt för main user 
        private string name;

        // Publik metod för att sätta värdet av 'name'
        public void SetName(string value)
        {
            name = value;
        }

        // Publik metod för att hämta värdet av 'name'
        public string GetName()
        {
            return name;  // Returnera det inkapslade namnet "Lawko"
        }
    }
}


// FEL KOD ? miss ??
