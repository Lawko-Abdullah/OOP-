﻿using System;

namespace AbstraktExempel
{
    // Abstrakt basklass !
    abstract class Fordon
    {
        public string Märke { get; set; }

        public Fordon(string märke)
        {
            Märke = märke;
        }

        // Abstrakt metod som måste implementeras i underklasser
        public abstract void Run();
    }

    // Underklass som ärver från basklassen Fordon
    class Bil : Fordon
    {
        public Bil(string märke) : base(märke) { }

        public override void Run()
        {
            Console.WriteLine($"{Märke} bilen kör iväg.");
        }
    }

    // Underklass som ärver från basklassen Fordon
    class Cykel : Fordon
    {
        public Cykel(string märke) : base(märke) { }

        public override void Run()
        {
            Console.WriteLine($"{Märke} cykeln trampas iväg.");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Skapar objekt av Bil och Cykel ?
            Fordon bil = new Bil("Ferrari");
            Fordon cykel = new Cykel("Mountain Bike ");

            // Anropar kör-metoden
            bil.Run();    // Output: Ferrari bilen kör iväg.
            cykel.Run();  // Output: Mountain Bike cykeln trampas iväg.


        }
    }
}
