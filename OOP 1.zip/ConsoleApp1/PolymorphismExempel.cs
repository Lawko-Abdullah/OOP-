﻿using System;

namespace PolymorphismExempel
{
    // Bas-klass blir Animal ? 
    class Animal
    {
        public virtual void MakeSound()
        {
            Console.WriteLine("The animal makes a sound.");
        }
    }

    //  class 1 - Hund 
    class Dog : Animal
    {
        public override void MakeSound()
        {
            Console.WriteLine("The dog barks.");
        }
    }

    // class 2 - Katt
    class Cat : Animal
    {
        public override void MakeSound()
        {
            Console.WriteLine("The cat meows.");
        }
    }
    // fel meddlande ?? miss med måsvingar löst !


    class Program
    {
        static void Main(string[] args)
        {
            // Polymorfism i aktion
            Animal myAnimal = new Animal();
            Animal myDog = new Dog();        // Skapa ett hundobjekt
            Animal myCat = new Cat();        // Skapa ett kattobjekt  
                                             // objekt begränsning ? 
            myAnimal.MakeSound();
            myDog.MakeSound();
            myCat.MakeSound();
        }                         // lärde mig att jag kan använda samma linje av kod makesound men att jag lägger det under specefika klass för att få ut olika ljud på djuren +

    }
}