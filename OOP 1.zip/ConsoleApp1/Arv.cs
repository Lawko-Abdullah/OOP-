﻿using System;

namespace ConsoleApp1
{
   
    
   
}

// Arv konecpt -- Bas klass 1
public class Djur
{
    public void Ljud()
    {
        Console.WriteLine("Djur gör ett ljud.");
    }
}

// Ärva Djur-klassen
public class Hund : Djur
{
    public void Skall()
    {
        Console.WriteLine("Hunden skäller!");
    }
}

// Programklassen
class Program
{
    static void Main(string[] args)
    {
        // Skapa en instans av Hund
        Hund minHund = new Hund();

        // Använd metoder från både bas- och underklass
        minHund.Ljud(); // Metod från bas-klass
        minHund.Skall(); // Metod från underklass
    }
}
